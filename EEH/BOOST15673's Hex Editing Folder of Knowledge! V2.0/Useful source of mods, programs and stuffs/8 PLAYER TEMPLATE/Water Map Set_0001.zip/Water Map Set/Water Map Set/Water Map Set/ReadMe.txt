ReadMe for "Water Map Set"
By: FuzzyTheGood
Host Site: http://ee.heavengames.com

This is a set of maps that are just plain water with underwater terrain. It is intended to be used for scenario creators who dislike
having to create all these large water maps.

Installation:
Copy and paste whatever map files you wish into the Empire Earth scenario folder.
It is most commonly found under this directory: "C:\Sierra\Empire Earth\Data\Scenarios"


Thank you for downloading!



If you have any questions, comments, or suggestions tell me on the file description page for Water Map Set.

-Thank you!