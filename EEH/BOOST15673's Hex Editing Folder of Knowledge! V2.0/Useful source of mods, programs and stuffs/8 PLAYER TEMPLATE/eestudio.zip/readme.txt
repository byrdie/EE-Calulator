Installation
------------

Run the EEStudio.msi file to install the program, if the install script
doesn't work, download the following file from Microsoft site :

Windows 95/98/ME/XP : http://www.microsoft.com/downloads/release.asp?ReleaseID=32831
Windows NT 4.0 and 2000 : http://www.microsoft.com/downloads/release.asp?releaseid=32832&NewList=1

Help/Comments/Bugs
------------------

If you have any problem with the program or simply want some help,
get on our forums and ask your question :

http://www.scnnetwork.com/cgi-bin/ikonboard/ikonboard.cgi

Copyrights/Credits
------------------

This program is copyrighted @ Nicolas Caron-Dauphin aka Enrique Orduno

Thanks to the following people :

AzN
Insane aka FatNick aka InsaneSpaghetti aka AI, etc.
EE Talon
Standil
Zen
Not Chooch(because he is sooo against modding)
SSSI/Sierra for allowing us to release it altough we would like to get more support ;-)
Ex-t
MacDonald
Wolfie
Buggi
And much much more people.... :-p