5000 World Pop v 1.0.1
by AzN (AznKnightmare)
AznKnightmare@hotmail.com
-----------------------------------------------

About: 
This mod makes the maximum population limit skyrocket to 5000. Normally, 1200 is the max, but with this mod in place, the
max is a whooping 5000. This will be slip among players, so it would be less, but still MUCH more per player than 1200 would
allow.
This mod works in multiplayer too! *

Explanation:
This was one of the most simple things I have ever created, or edited. I changed two bytes, then volia!
People who think 5000 is not enough, I want to see you use 600+ units, in a 8 player game. If you can tell me that
does not lag, with 5000 units on screen, then I will make one with 9999 population.

WARNING: Not resonsible if your comp cant handle that much units.
WARNING 2: This modpack changes version numbers. You cannot play people without this modpack installed. Remove it
if you need to play normally.

Installation:
Thanks to how Empire Earth works, all you have to do is extract this modpack into the follow folder:

X:\Sierra\Empire Earth\Data\db **

"X" would be the drive in which you installed Empire Earth in. So if you only have one harddrive, it would most likely be C.

Uninstall:
Just delete the file from your X:\Sierra\Empire Earth\Data\db folder.

Props:
Thanks to:

(I finally figured out something for myself!)

Help:
If you have trouble installing, running, or removing modpacks goto:
http://www.scnnetwork.com/cgi-bin/ikonboard/ikonboard.cgi

That is official boards for EE Studio, and it is where we (Enrique Orduno and myself)  will be answering questions.
If you want to create your own modpack, you can goto the same site listed above, and we will try to help.


* All players must have this modpack. Players who do not have this mod installed, will not be able to join a game. This modpack
changes the version of Empire Earth. With this modpack installed, you may no longer play people without the modpack,
unless you uninstall it. You also may not update Empire Earth with this modpack installed. You must uninstall, update, and
then reinstall the mod.

** You may have to create this directory