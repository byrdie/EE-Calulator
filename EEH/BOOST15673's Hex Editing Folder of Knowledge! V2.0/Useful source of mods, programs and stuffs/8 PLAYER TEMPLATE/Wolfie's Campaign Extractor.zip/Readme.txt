Wolfie's Campaign Extractor

-------------
INSTALLATION:
-------------

1) Copy the .exe file(s) into the folder of your choosing.  They must be in the same folder for Wolfie's Campaign Extractor to work.