incomplete tutorial, more than enought to get you started....included an application for you to see some values and then search in hex :P

also, check eeh forums!!!

anyways, got yet another 2 sheats with unit info so you can search values easier....

and a tutorial not by me
