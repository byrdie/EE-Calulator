This program will open, extract all files and using DCL.EXE (from EE Studio) it will decompress all files inside an Empire Earth campaign file (*.SSA).  All files that were inside the SSA file will be extracted to a folder with full directory paths that were inside the SSA file.

If you don't have VB6 runtime libraries, you will need them: http://www.wolfiesden.com/downloads/images/vbrun.htm

You will also need EE Studio installed.
http://ee.heavengames.com/cgi-bin/forums/display.cgi?action=ct&f=3,3832,1,10

Unzip this program to the same folder where you installed EE Studio OR you can copy DCL.EXE from your EE Studio folder to where you want this program to run from.

Enjoy,
Wolfie
wolfie@wolfiesden.com
