This will have a maximum of 10 people in mines and berries, also 20 citizens selected by default 
in single mode to save time to set up the game now.

Con esto tendr�s un lim�te m�ximo de 10 ciudadanos en minas y bayas, tambi�n se seleccionar�n 
20 ciudadanos por defecto en el modo individual para ahorrar tiempo a la ahora de configurar 
la partida.

Instalaci�n: Copiar el archivo dentro de la carpeta db , si no hay crearla dentro de EE_AOC/Data 

Installation: Copy the file inside the folder db, if no create within EE_AOC / Data